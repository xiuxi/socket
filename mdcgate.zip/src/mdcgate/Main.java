package mdcgate;

import java.io.File;
import java.net.URL;

import org.apache.commons.io.FileUtils;

public class Main {

	public static void main(String[] args) {
		for (int i = 3836; i < 10000*10; i++) {
			try {
//				Thread.sleep(1000);
				FileUtils.copyURLToFile(new URL("http://mdcgate.com/viettv/get_url_by_id.php?ChannelId="+i), 
						new File("D:\\mdcgate.com\\"+i));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
