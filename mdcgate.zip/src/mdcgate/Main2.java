package mdcgate;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Main2 {

	static String urlStart = "\"url\":\"";

	public static void getUrls(List<String> urlsList, String url) {
		int urlStartIndex = url.indexOf(urlStart);
		if (urlStartIndex >= 0) {
			url = url.substring(urlStartIndex + urlStart.length());
			int doubleQuoteIndex = url.indexOf("\"");
			if (doubleQuoteIndex >= 0) {
				String urlStr = url.substring(0, doubleQuoteIndex);
				url = url.substring(urlStr.length());
				if (urlStr.length() > 0) {
					urlStr = urlStr.replace("\\r\\n", "");
					urlStr = urlStr.replace("\\", "");
					urlsList.add(urlStr);
				}
				getUrls(urlsList, url);
				System.out.println("" + urlStr);
			}
		}
	}

	public static void main(String[] args) {
		File urls = new File("D:\\mdcgate.com\\urls.txt");
		for (int i = 0; i < 100000; i++) {
			try {
				File file = new File("D:\\mdcgate.com\\" + i);
				if (!file.exists()) {
					break;
				}
				String content = FileUtils.readFileToString(file);
				List<String> urlsList = new ArrayList<>();
				getUrls(urlsList, content);

				for (String url : urlsList) {
					if (url.startsWith("http") && (url.contains(".m3u8") || url.contains(".ts"))) {
						File urlFile = new File("D:\\mdcgate.com_url\\" + i + "_url.txt");
						try {
							FileUtils.copyURLToFile(new URL(url), urlFile, 2000, 2000);
							String urlFileContent = FileUtils.readFileToString(urlFile);
							if (urlFileContent.contains("#EXTM3U")) {
								System.out.println(url);
								FileUtils.write(urls, url + "\r\n", true);
							}
						} catch (Exception e) {
							System.out.println(e.getMessage());
							// e.printStackTrace();
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
