<?php
define('ROOT_PART', Root_part());
define('APIKEY', 'AIzaSyAk75W1-qg0UBp1R72-wbvJTFCiJHhAzfs');
define('GJ_CODE', '中国');
define('SITE_NAME', 'my');
define('TITLENAME', 'my');
define('EN2DEKEY', '9Ls5KVG7CK');
define('EMAIL', 'xiuxi554325746@gmail.com');
?>