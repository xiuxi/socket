nohup ./goflyway -k=198512 > /dev/null 2>&1 &
