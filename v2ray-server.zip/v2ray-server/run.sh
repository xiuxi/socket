cd /root/v2ray-server
chmod a+x *
nohup ./v2ray -config config.json >> ssserver.log 2>&1 &