from django.contrib import admin
from app.submodels.customer import Customer, CustomerAdmin
from app.submodels.customer_price import CustomerPrice, CustomerPriceAdmin
from app.submodels.product import Product, ProductAdmin
from app.submodels.product_sell import ProductSell, ProductSellAdmin
from app.submodels.supply import Supply, SupplyAdmin
from app.submodels.supply_price import SupplyPrice, SupplyPriceAdmin
from app.submodels.product_buy import ProductBuy, ProductBuyAdmin
from app.submodels.payment import Payment, PaymentAdmin
from app.submodels.receipt import Receipt, ReceiptAdmin

# Register your models here.
admin.site.register(Customer, CustomerAdmin)
admin.site.register(CustomerPrice, CustomerPriceAdmin)
admin.site.register(Supply, SupplyAdmin)
admin.site.register(SupplyPrice, SupplyPriceAdmin)
admin.site.register(Product, ProductAdmin)
admin.site.register(ProductBuy, ProductBuyAdmin)
admin.site.register(ProductSell, ProductSellAdmin)
admin.site.register(Payment, PaymentAdmin)
admin.site.register(Receipt, ReceiptAdmin)

