from django.db import models
from django.contrib import admin
from app.submodels.supply import Supply
from app.submodels.product import Product

class SupplyPrice(models.Model):
    supply_price_id = models.AutoField(primary_key=True, verbose_name=u"采购价格id")
    supply_id = models.ForeignKey(Supply, on_delete=models.CASCADE, verbose_name=u"供应商名称")
    product_id = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name=u"商品名称", blank=True)
    price = models.FloatField(default=0, verbose_name=u"进货价格", blank=True)
    remark = models.CharField(default=None,max_length=200, verbose_name=u"备注", blank=True,null=True)
    
    class Meta:
        db_table = 'supply_price'
        verbose_name = '采购价格'
        verbose_name_plural = '采购价格列表'
        ordering = ['supply_id']
    def __str__(self):
        return "采购价格"
        
class SupplyPriceAdmin(admin.ModelAdmin):
    list_display = ('supply_id', 'product_id','price','remark',)
    search_fields = ('supply_id__supply_name','product_id__product_name','price')   
    list_filter = ('supply_id', 'product_id',)  