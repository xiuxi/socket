from django.db import models
from django.db.models.fields import TextField
from django.contrib import admin
from app.submodels.customer import Customer
from app.submodels.product import Product
from _datetime import datetime
from app.submodels.supply import Supply

class ProductBuy(models.Model):
    product_buy_id = models.AutoField(primary_key=True)  # 服务id
    supply_id = models.ForeignKey(Supply, on_delete=models.CASCADE, verbose_name=u"供应商名称")
    product_id = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name=u"商品名称")
    amount = models.FloatField(verbose_name=u"采购数量")
    price = models.FloatField(default=0,verbose_name=u"单价")
    total = models.FloatField(default=0, verbose_name=u"金额")
    paid = models.BooleanField(default=False, verbose_name=u"金额")
    time = models.DateTimeField(default=datetime.now(), verbose_name=u"采购时间")
    remark = models.CharField(default=None,max_length=200, verbose_name=u"备注", blank=True,null=True)
    
    
    class Meta:
        db_table = 'product_buy'
        verbose_name = '采购'
        verbose_name_plural = '采购列表'
        ordering = ['supply_id']
    def __str__(self):
        return "采购 "
        
class ProductBuyAdmin(admin.ModelAdmin):
    list_display = ('supply_id', 'product_id', 'amount', 'price', 'total', 'time','remark', )
    search_fields = ('supply_id__supply_name','product_id__product_name','amount','time')   
    list_filter = ('supply_id', 'product_id',)
    def save(self):
        self.paid = 11
        super(ProductBuy, self).save()
    def get_form(self, request, obj=None, **kwargs):
        print(obj)
        return admin.ModelAdmin.get_form(self, request, obj=obj, **kwargs)
    def save_model(self, request, obj, form, change):
        print("hello")
        admin.ModelAdmin.save_model(self, request, obj, form, change)
    
    
    
    
