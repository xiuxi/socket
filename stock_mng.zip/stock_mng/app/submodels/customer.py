from django.db import models
from django.contrib import admin

class Customer(models.Model):
    customer_id = models.AutoField(primary_key=True, verbose_name=u"超市id")
    customer_name = models.CharField(default=None,max_length=200, verbose_name=u"超市名称")
    remark = models.CharField(default=None,max_length=200, verbose_name=u"备注", blank=True,null=True)
    
    class Meta:
        db_table = 'customer'
        verbose_name = '超市'
        verbose_name_plural = '超市列表'
        ordering = ['customer_name']
    def __str__(self):
        return "%s" % self.customer_name
        
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('customer_name','remark',)
    search_fields = ('customer_name',)   
    list_filter = ('customer_name',) 
 