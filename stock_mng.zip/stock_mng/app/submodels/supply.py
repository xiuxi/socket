from django.db import models
from django.db.models.fields import TextField
from django.contrib import admin

class Supply(models.Model):
    supply_id = models.AutoField(primary_key=True)
    supply_name = models.CharField(default=None, max_length=100, verbose_name=u"供应商名称")
    remark = models.CharField(default=None,max_length=200, verbose_name=u"备注", blank=True,null=True)

    class Meta:
        db_table = 'supply'
        verbose_name = '供应商'
        verbose_name_plural = '供应商列表'
        ordering = ['supply_name']

    def __str__(self):
        return "供应商"
    
    
class SupplyAdmin(admin.ModelAdmin):
    list_display = ('supply_name','remark',)
    
