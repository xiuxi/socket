from django.db import models
from django.contrib import admin
from django.db.models import Count
from django.db.models.aggregates import Sum


class Product(models.Model):
    product_id = models.AutoField(primary_key=True, verbose_name=u"商品Id")
    product_name = models.CharField(default=None,max_length=200, verbose_name=u"商品名称")
    category_name = models.CharField(default=None,max_length=200, verbose_name=u"商品分类", blank=True,null=True)
    remark = models.CharField(default=None,max_length=200, verbose_name=u"备注", blank=True,null=True)

    class Meta:
        db_table = 'product'
        verbose_name = '商品'
        verbose_name_plural = '商品列表'
        ordering = ['product_name']
    def __str__(self):
        return "%s" % self.product_name
        
class ProductAdmin(admin.ModelAdmin):
    list_display = ('product_name','category_name', 'show_stock','remark', )
    search_fields = ('product_name',)
    list_filter = ('product_name','category_name',) 
    def show_stock(self, instance):
        from app.submodels.product_sell import ProductSell
        from app.submodels.product_buy import ProductBuy
        amount = 0
        
        
        buy_amount = 0
        product_buys = ProductBuy.objects.filter(product_id=instance.product_id).values('amount')
        
        for product_buy in product_buys:
            buy_amount = buy_amount + product_buy['amount']
            
        sell_amount = 0
        product_sells =  ProductSell.objects.filter(product_id=instance.product_id).values('amount')
        for product_sell in product_sells:
            sell_amount = sell_amount + product_sell['amount']
        return amount - sell_amount + buy_amount
    show_stock.short_description = "库存"
    show_stock.admin_order_field = 'product_name'
