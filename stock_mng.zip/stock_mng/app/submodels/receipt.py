from django.db import models
from django.contrib import admin
from app.submodels.customer import Customer
from _datetime import datetime

class Receipt(models.Model):
    receipt_id = models.AutoField(primary_key=True, verbose_name=u"收款id")
    customer_id = models.ForeignKey(Customer, on_delete=models.CASCADE, verbose_name=u"超市名称")
    amount = models.FloatField(verbose_name=u"收款金额")
    time = models.DateTimeField(default=datetime.now(), verbose_name=u"收款时间")
    remark = models.CharField(default=None,max_length=200, verbose_name=u"备注", blank=True,null=True)
    
    class Meta:
        db_table = 'receipt'
        verbose_name = '收款'
        verbose_name_plural = '收款列表'
        ordering = ['customer_id']
    def __str__(self):
        return "收款"
        
class ReceiptAdmin(admin.ModelAdmin):
    list_display = ('customer_id','amount','time','remark',)
    search_fields = ('customer_id',)   
    list_filter = ('customer_id',) 
