from django.db import models
from django.contrib import admin
from app.submodels.product import Product
from app.submodels.customer import Customer
from django import forms

class CustomerPrice(models.Model):
    customer_price_id = models.AutoField(primary_key=True, verbose_name=u"商品售价id")
    customer_id = models.ForeignKey(Customer, on_delete=models.CASCADE,verbose_name=u"超市名称")
    product_id = models.ForeignKey(Product, on_delete=models.CASCADE,verbose_name=u"商品名称")
    price = models.FloatField(verbose_name=u"商品售价")
    remark = models.CharField(default=None,max_length=200, verbose_name=u"备注", blank=True,null=True)
    
    class Meta:
        db_table = 'customer_price'
        verbose_name = '销售价'
        verbose_name_plural = '销售价列表'
        ordering = ['customer_id']
    def __str__(self):
        return "销售价 "

class CustomerPriceAdmin(admin.ModelAdmin):
    list_display = ('customer_id','product_id','price','remark')
    search_fields = ('customer_id__customer_name','product_id__product_name','price')   
    

