from django.db import models
from django.contrib import admin
from app.submodels.supply import Supply
from _datetime import datetime

class Payment(models.Model):
    payment_id = models.AutoField(primary_key=True, verbose_name=u"付款id")
    supply_id = models.ForeignKey(Supply, on_delete=models.CASCADE, verbose_name=u"供应商名称")
    amount = models.FloatField(verbose_name=u"付款金额")
    time = models.DateTimeField(default=datetime.now(), verbose_name=u"付款时间")
    remark = models.CharField(default=None,max_length=200, verbose_name=u"备注", blank=True,null=True)
    
    class Meta:
        db_table = 'payment'
        verbose_name = '付款'
        verbose_name_plural = '付款列表'
        ordering = ['supply_id']
    def __str__(self):
        return "付款"
        
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('supply_id','amount','time','remark',)
    search_fields = ('supply_id__supply_name',)   
    list_filter = ('supply_id',) 
