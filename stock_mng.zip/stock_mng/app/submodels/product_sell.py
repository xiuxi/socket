from django.db import models
from django.db.models.fields import TextField
from django.contrib import admin
from app.submodels.customer import Customer
from _datetime import datetime


class ProductSell(models.Model):
    from app.submodels.product import Product
    product_sell_id = models.AutoField(primary_key=True)  # 服务id
    customer_id = models.ForeignKey(Customer, on_delete=models.CASCADE, verbose_name=u"超市名称")
    product_id = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name=u"商品名称")
    amount = models.FloatField(verbose_name=u"送货数量")
    price = models.FloatField(verbose_name=u"单价")
    total = models.FloatField(verbose_name=u"金额")
    time = models.DateTimeField(default=datetime.now(), verbose_name=u"送货时间")
    remark = models.CharField(default=None,max_length=200, verbose_name=u"备注", blank=True,null=True)
    
    class Meta:
        db_table = 'product_sell'
        verbose_name = '销售'
        verbose_name_plural = '销售列表'
        ordering = ['-time']
    def __str__(self):
        return "销售 "
        
class ProductSellAdmin(admin.ModelAdmin):
    list_display = ('customer_id', 'product_id', 'amount','price','total', 'time','remark', )
    search_fields = ('customer_id__customer_name','product_id__product_name','amount','time')   
    list_filter = ('customer_id', 'product_id',)
    
    


    
    
