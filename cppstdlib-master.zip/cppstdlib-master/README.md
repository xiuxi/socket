![](https://cloud.githubusercontent.com/assets/6889915/19406570/f04138e2-92ba-11e6-949f-b42755d98cb6.jpg)

The C++ Standard Library - A Tutorial and Reference, 2nd Edition
http://www.cppstdlib.com
=================================================

 [![Build Status](https://travis-ci.org/iZhangHui/cppstdlib.svg?branch=master)](https://travis-ci.org/iZhangHui/cppstdlib) ![Language](https://img.shields.io/badge/language-C%2B%2B11-orange.svg) [![License](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE.md)

Installation
------------
```
git clone https://github.com/iZhangHui/cppstdlib.git
cd cppstdlib
mkdir build && cd build
cmake ..
make -j4

```
